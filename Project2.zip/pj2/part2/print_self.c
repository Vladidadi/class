//Vladislav Vitmaer
  #include <linux/kernel.h>
  #include <linux/sched.h>
  #include <linux/module.h>
 
  int init_module(void)
  {
    printk(KERN_INFO "Printing Self!\n");

  struct task_struct *task;
    char *print_state;
   for(task=current;task!=&init_task;task=task->parent)

   {
   switch(task->__state){
    case 0:
    print_state=    "TASK_RUNNING"   ;
    break;
    case 1:
    print_state= "TASK_INTERRUPTIBLE" ;
    break;
    default:
    print_state="error not enumerated";
   }
  
   printk(KERN_INFO "heres a task named %s with PID [%d] whose state is %s\n",task->comm , task->pid,print_state);
   }
  
   return 0;
   }
   
   void cleanup_module(void)
   {
   printk(KERN_INFO "End Printing Self\n");
   }


MODULE_LICENSE("GPL");
MODULE_AUTHOR("Vladislav Vitmaer");
MODULE_DESCRIPTION("Process information report");