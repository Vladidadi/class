#include <linux/module.h>
#include <linux/kernel.h>

int init_module(void)      {
        printk(KERN_INFO "Hello World!\n");
        return 0;
}

void cleanup_module(void){
    printk("Goodbye World!\n");
}

//module_init(init_module);
//module_exit(cleanup_module);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Vladislav Vitmaer");
MODULE_DESCRIPTION("First keneal module");