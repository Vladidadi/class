NAME OF PROJECT: Project 2 Kernal Modules
================


MEMBERS: Vladislav Vitmaer
========


STATEMENT:
==========
We have neither given nor received unauthorized assistance on this work.


VIRTUAL MACHINE (VM) INFORMATION:
=================================
EAS_Datacenter/Instruction/Instruction/VladislavUbuntu
NAME OF VIRTUAL MACHINE (VM): VladislavUbuntu
USENAME: vlad
PASSWORD: ' '               //spacebar

Describe where the files can be found.
/home/vlad/class/Project2.zip

Describe each file and the purpose it serves. 
The files can be found in the pj2 folder, they follow this general layout:
─ pj2
    ├── part1
    │   ├── hello.c
    │   └── Makefile
    ├── part2
    │   ├── Makefile
    │   └── print_self.c
    ├── part3
    │   ├── Makefile
    │   └── print_other.c
    ├── part4
    │   ├── example2.c
    │   └── Makefile
    ├── Project 2 - Kernel Modules and Processes-1.pdf
    ├── readme.txt
    └── writeup.docx

    Where the source code files contain the modules and the makefiles help to build them cleanly

Provide any special instructions to access or run your program.
Step into each parts directory and run `make` to compile and load the module, and see its output.
Once finished run `make clean` to remove the module as well as removing the object files.



ROOT PASSWORD: ' '
==============


DESCRIPTION AND REMEDIATION: A project exploring the concept of kernal modules and familiarizing us with the structure of linux processes.
============================
