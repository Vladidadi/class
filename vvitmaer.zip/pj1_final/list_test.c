#include "list.h"
// #include <cstddef>
// #include <cstddef.h>

#include "stdlib.h"
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

// int main2(){
//     node* nodee = malloc(sizeof(node));
//     free(nodee);
// }
int main(){
    list *tasty_foods =create_list();
    if(tasty_foods->head != NULL && tasty_foods){
        return 1;
    }else{
    
    ///    
    puts("\n\t\t\tList Created\t\t\t\n");
    print_list(tasty_foods);


    short zero=0;
    zero+=add_to_list(tasty_foods,"lasagna");
    zero+=add_to_list(tasty_foods,"empanadas");
    zero+=add_to_list(tasty_foods,"salted fish");
    zero+=add_to_list(tasty_foods,"lentil soup");
    // printf("%d",true);
    if(zero!=0){
         return 2;
    }else{

    ///
    puts("\n\t\t\tFour Items Added\t\t\t\n");
    print_list(tasty_foods);
    char* should_be_lasagna=remove_from_list(tasty_foods);
    char* should_be_empanadas=remove_from_list(tasty_foods);
    puts("\n\t\t\tFirst 2 Items Removed\t\t\t\n");
    print_list(tasty_foods);


    if (strcmp(should_be_lasagna,"lasagna") && strcmp(should_be_empanadas,"empanadas")){
        return 3;
    }else{

    flush_list(tasty_foods);
    
    ///l=remove_f
    puts("\n\t\t\tList Flushed\t\t\t\n");
    print_list(tasty_foods);

    free_list(&tasty_foods);
    if(tasty_foods!=NULL){
        //should never run if working properly
    printf("\nhead address: %p\tlist address:%p\n",tasty_foods->head,tasty_foods);
    }else{
    puts("\n\t\t\tList freed\t\t\t\n");
    }
    print_list(tasty_foods);

    //added additional tests
    remove_from_list(tasty_foods);
    int should_be_minus_one = add_to_list(tasty_foods,"leftovers");
    if(should_be_minus_one!=-1){
        return 4;
    }else{
    create_list(tasty_foods);
    remove_from_list(tasty_foods);
    create_list(tasty_foods);

    // printf("\nhead address: %d\sthead value:%d",tasty_foods->head,tasty_foods->head->item);


    }
    }



    }



    }

    return 0;

}