//
#include "list.h"
// #include <cstddef>

#include "stdlib.h"
#include <stdbool.h>
#include <stdio.h>


// list* create_list(){
//   node* head_node = malloc(sizeof(node));
//   // head_node=NULL;
//   head_node->item=NULL;
//   head_node->next=NULL;
//   list* ll = malloc(sizeof(list));
//   ll->head= head_node;

//   return ll;
// }
list* create_list(){
  list* ll = malloc(sizeof(list));
  ll->head=NULL;
  return ll;
}

//if null add item to head
//elif not null {
/*SCRATCH
 move the item in head into next. (possibly create next node)
 link the second node's next to null
 link the head to next if not done
 write item into head
  // char* temp = ll->head->item;
  // ll->head->next=malloc(sizeof(node));
  // ll->head->next->item=temp;

  // ll->head->next->item=NULL;

  // ll->head->item=item;
*/
int add_to_list (list *ll, char* item){
  //validator
  if(!ll){
    return -1;
  }else{
  if(!item){
    return 1;
  }else{
//allocator
  node* new=malloc(sizeof(node));
  if(!new){
    return 2;
  }else{

  node* current=ll->head;
  //empty list case
  if(!current){
    new->item=item;
    new->next=NULL;
    ll->head=new;

    return 0;
  }else{
    //iterator
  while(current->next!=NULL){
    current=current->next;
  }
  //setter
  current->next=new;
  new->item=item;
  // bool cpy_ok=false;
  // int count = strcpy(new->item,item);
  // printf("\n\tgot:%d\texpected:%d",count,strlen(item));


  return 0;
}
}
}
}
}
/*
remove the head
move the head
read the removed head
frees removed head*/
char* remove_from_list(list *ll){
  if(ll&&ll->head){
  node* old_head= ll->head;
  
  node* next_ptr = ll->head->next;

  char* string = old_head->item;

  free (old_head);

  ll->head=next_ptr;

  return string;
}else{
  return "";
}
}
void print_list(list *ll){
  if(ll==NULL){
    puts("\nprint called on dealocated list\n");
    return;
  }else if(ll->head == NULL){
  puts("\nprint called on empty list\n");
  return;
  }
  else{

  node* current=ll->head;
  // char count=0;
  printf("\n\nLIST CONTENTS\n");
  while(current->next!=NULL){
    printf("[\t%p:\t%s\t]\n",current,current->item);// 1 thru n-1
    current=current->next;
  
  }
    printf("[\t%p:\t%s\t]\n",current,current->item);// n
puts("\n");

  }
}   

void flush_list(list *ll){  


    node* current=0x00;
    node* second_to_last=0x00;
    while(ll->head!=NULL){
      current=ll->head;//needs to be set each time
      second_to_last=0x00;

      while(current->next != NULL){
        // printf("%p%s",current,current->item);
        second_to_last=current;
        current=current->next;
      }
      current->item=NULL;
      current->next=NULL;
      free(current);
      current=NULL;
      if(second_to_last){
      second_to_last->next=NULL;
      }else{
        // free(ll->head);
        ll->head=NULL;
      }
  }

  // current->item=NULL;
  // node* link = current->next;

  // while(link!=NULL){
  //   current=link;
  //   link=link->next;
  //   free(current);

   
    /* 
    This loop runs while the head's next node exists.
    It finds the last node, and frees it.
    *//*
    node* current=0x00;
    do{
      current=ll->head;//needs to be set each time

      while(current->next&&current->item){
      current=current->next;
      }
      // free(current->item);
      free(current);

    }while(ll->head->next!=NULL);
    // current=current->next;
*/
}


void free_list(list **ll){
  // free(ll->head);
  // flush_list(&ll);
  // list* list_ptr = &ll;~
  // free(list_ptr);
  // free (list_ptr);
  // free(&ll);
  free(*ll);
  *ll=NULL;
}
