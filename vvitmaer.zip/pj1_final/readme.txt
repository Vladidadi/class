#PJ1 README
## Vladislav Vitmaer
We have neither given nor received unauthorized assistance on this work

The directory and name of my virtual machine
The path in VM where my code is located 
the password for the account that can run the code
a brief description of how I solved the problems and what I learned


I knew the char pointers would be hard to work with,
I've always used fixed size arrays in the past.
Here I wrote the structure of the code first, 
then went back to fix the copying once e
I initally did free backwards, but thanks to an insightful stackexchange thread 
I changed it to free the nodes in reverse order.
verything compiled.
The char pointers ended up being quite easy to work with after all.


the que like structure

the flush vs free was difficult. I while looped thru the list,
checking it was safe to jump to the next node before doing so. 

I thought it would be nice to abstract the 'find next valid node' while loop, 
but it was always doing slightly different things so I ended up writing out the 
3 variations in the different functions.

the print statement was interesting because I had the case where I would fault 
if this was called on a freed list, which is a serious runtime error. 


I initally did free backwards, but thanks to an insightful stackexchange thread 
I changed it to free the nodes in reverse order.

I thought the article on makefiles was very insightful. Like someone had read many chapters 
of a book, and condensed it into a few pages for the makefile newbie. Pretty cool.

The flush was the most difficult function, with print being a close second
(because I wanted to not segfault if print was called on an empty or flushed list). 
On the final revision of the flush function I ended up with 2 nested while loops, 
along with 2 node pointers. One for the current node, and one for the one before it.
Since the list isnt doubly linked, I can't jump back after iterating, so thats why theres
two nodes tracked. I iterated on current having a next node in the inner while loop,
and freed nodes in the outer one while the head wasnt null.